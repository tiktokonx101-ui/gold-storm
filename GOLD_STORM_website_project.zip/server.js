require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
if (process.env.NODE_ENV === 'production' && (!JWT_SECRET || JWT_SECRET.length < 32)) {
  throw new Error('Set JWT_SECRET to a random value of at least 32 characters in production.');
}
const secret = JWT_SECRET || 'local-development-only-secret-change-before-deployment';
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'gold-storm.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS brokers (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, tagline TEXT NOT NULL, spread TEXT NOT NULL,
 bonus TEXT NOT NULL, note TEXT NOT NULL, description TEXT NOT NULL, features TEXT NOT NULL,
 links TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clicks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, broker_id TEXT NOT NULL, region TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admin_users (
 username TEXT PRIMARY KEY, password_hash TEXT NOT NULL
);
`);
const initial = [
 {id:'pu-prime',name:'PU PRIME',tagline:'خيارات تداول متعددة',spread:'3.2',bonus:'50% حتى 1,000 دولار',note:'البونص قابل للخسارة فقط وفق الشروط المعلنة.',description:'وسيط تداول دولي. تحقّق من الكيان القانوني الذي سيفتح حسابك لديه ومن توافر الخدمات في بلد إقامتك قبل التسجيل.',features:['راجع أنواع الحسابات المتاحة في بلدك','اقرأ شروط البونص والسحب قبل الإيداع','تحقّق من الجهة القانونية والتنظيمية ذات الصلة'],links:{iraqSyria:'https://www.puprime.net/forex-trading-account/?affid=MjMyMTgyMzg=',other:'https://puvip.co/la-partners/6bxpoPNx'}},
 {id:'vantage',name:'VANTAGE',tagline:'منصة لاحتياجات تداول مختلفة',spread:'2.9',bonus:'150% حتى 1,000 دولار',note:'البونص قابل للتداول والخسارة وفق الشروط المعلنة.',description:'راجع الشروط الرسمية والكيان الذي يخدم بلدك، إذ قد تختلف المنتجات والعروض المتاحة بحسب المنطقة ونوع الحساب.',features:['قارن شروط الحسابات قبل الاختيار','تحقّق من تفاصيل العرض والأهلية','راجع الرسوم وشروط السحب لدى الوسيط'],links:{default:'https://vigco.co/la-com-inv/Q1Z6ltS8'}},
 {id:'startrader',name:'STARTRADER',tagline:'حلول تداول عبر الإنترنت',spread:'3.1',bonus:'50% حتى 1,000 دولار',note:'البونص قابل للتداول والخسارة وفق الشروط المعلنة.',description:'اقرأ الإفصاحات الرسمية وتحقّق من توافر الحساب والعرض في بلدك قبل مشاركة بياناتك أو إيداع الأموال.',features:['تحقّق من الجهة المتعاقدة معك','افهم قيود البونص قبل قبوله','قارن التكاليف الفعلية للحساب'],links:{default:'https://www.startrader.com/live-account/?affid=Mjc4MjY1ODM=&ibpRebateCode=Mjc4MjY1ODNTVDEwNDUw'}},
 {id:'neex',name:'NEEX',tagline:'خيارات حسابات تداول',spread:'2.6',bonus:'100% حتى 300 دولار',note:'البونص قابل للتداول والخسارة وفق الشروط المعلنة.',description:'تفاصيل المنتجات والأهلية والشروط قد تختلف حسب بلد الإقامة ونوع الحساب؛ راجع المصدر الرسمي قبل التسجيل.',features:['تحقّق من أهلية بلدك','راجع متطلبات التداول والسحب','لا تعتبر البونص رصيداً نقدياً مضموناً'],links:{default:'https://cp.neex.com/register/index?invitationCode=GXNG6C2G'}}
];
const count = db.prepare('SELECT COUNT(*) n FROM brokers').get().n;
if (!count) {
 const insert = db.prepare('INSERT INTO brokers (id,name,tagline,spread,bonus,note,description,features,links) VALUES (@id,@name,@tagline,@spread,@bonus,@note,@description,@features,@links)');
 const tx = db.transaction(rows => rows.forEach(b => insert.run({...b,features:JSON.stringify(b.features),links:JSON.stringify(b.links)})));
 tx(initial);
}
if (process.env.ADMIN_USERNAME && process.env.ADMIN_PASSWORD) {
 const exists = db.prepare('SELECT username FROM admin_users WHERE username=?').get(process.env.ADMIN_USERNAME);
 if (!exists) db.prepare('INSERT INTO admin_users (username,password_hash) VALUES (?,?)').run(process.env.ADMIN_USERNAME, bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12));
}
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:'100kb'}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
const loginLimiter = rateLimit({windowMs:15*60*1000, max:8, standardHeaders:true, legacyHeaders:false});
function requireAdmin(req,res,next) {
 try {
  const token = req.cookies.gs_admin;
  const payload = jwt.verify(token, secret);
  if (payload.role !== 'admin') throw new Error('role');
  next();
 } catch { res.status(401).json({error:'يلزم تسجيل الدخول إلى لوحة التحكم.'}); }
}
function cleanBroker(row) {
 return {...row, features:JSON.parse(row.features), links:JSON.parse(row.links)};
}
app.get('/api/brokers', (req,res) => {
 res.set('Cache-Control','no-store');
 res.json(db.prepare('SELECT * FROM brokers ORDER BY name').all().map(cleanBroker));
});
app.post('/api/admin/login', loginLimiter, (req,res) => {
 const {username,password} = req.body || {};
 const user = db.prepare('SELECT * FROM admin_users WHERE username=?').get(String(username||''));
 if (!user || !bcrypt.compareSync(String(password||''), user.password_hash)) return res.status(401).json({error:'اسم المستخدم أو كلمة المرور غير صحيحة.'});
 const token = jwt.sign({sub:user.username,role:'admin'}, secret, {expiresIn:'8h'});
 res.cookie('gs_admin', token, {httpOnly:true, sameSite:'strict', secure:process.env.NODE_ENV==='production', maxAge:8*60*60*1000});
 res.json({ok:true});
});
app.post('/api/admin/logout', (req,res) => {res.clearCookie('gs_admin',{httpOnly:true,sameSite:'strict',secure:process.env.NODE_ENV==='production'});res.json({ok:true});});
app.get('/api/admin/me', requireAdmin, (req,res) => res.json({ok:true}));
app.put('/api/admin/brokers/:id', requireAdmin, (req,res) => {
 const id = String(req.params.id);
 const old = db.prepare('SELECT * FROM brokers WHERE id=?').get(id);
 if (!old) return res.status(404).json({error:'الوسيط غير موجود.'});
 const b = req.body || {};
 const allowed = ['name','tagline','spread','bonus','note','description'];
 const update = {};
 for (const k of allowed) update[k] = String(b[k] ?? old[k]).trim().slice(0,2000);
 let links, features;
 try {
  links = b.links ? JSON.stringify(b.links) : old.links;
  features = b.features ? JSON.stringify(b.features) : old.features;
  const parsed = JSON.parse(links);
  if (typeof parsed !== 'object' || !parsed) throw new Error();
  for (const url of Object.values(parsed)) if (typeof url !== 'string' || !/^https:\/\/\S+$/i.test(url)) throw new Error();
  const feat = JSON.parse(features);
  if (!Array.isArray(feat) || feat.some(x => typeof x !== 'string')) throw new Error();
 } catch { return res.status(400).json({error:'تحقّق من صيغة الروابط والمميزات. يجب أن تكون الروابط HTTPS.'}); }
 db.prepare('UPDATE brokers SET name=@name,tagline=@tagline,spread=@spread,bonus=@bonus,note=@note,description=@description,features=@features,links=@links,updated_at=CURRENT_TIMESTAMP WHERE id=@id')
 .run({...update,features,links,id});
 res.json({ok:true,broker:cleanBroker(db.prepare('SELECT * FROM brokers WHERE id=?').get(id))});
});
app.post('/api/click', (req,res) => {
 const {brokerId,region} = req.body || {};
 const valid = db.prepare('SELECT id FROM brokers WHERE id=?').get(String(brokerId||''));
 if (!valid) return res.status(400).json({error:'وسيط غير معروف.'});
 db.prepare('INSERT INTO clicks (broker_id,region) VALUES (?,?)').run(valid.id,String(region||'').slice(0,30));
 res.json({ok:true});
});
app.get('/api/admin/stats', requireAdmin, (req,res) => {
 const totals = db.prepare('SELECT broker_id, COUNT(*) clicks FROM clicks GROUP BY broker_id').all();
 res.json({clicks:totals});
});
app.get('/admin', (req,res) => res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => console.log(`GOLD STORM running at http://localhost:${PORT}`));
